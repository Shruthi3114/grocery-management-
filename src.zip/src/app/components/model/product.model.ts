export interface Product{
    description: string;
    image: string;
    mrpPrice : number;
    productId : number;
    productname :string;
    quantity: number;
    category: string;
    measurment: string;
}
