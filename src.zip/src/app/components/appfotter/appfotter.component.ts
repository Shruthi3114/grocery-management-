import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-appfotter',
  templateUrl: './appfotter.component.html',
  styleUrls: ['./appfotter.component.css']
})
export class AppfotterComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
